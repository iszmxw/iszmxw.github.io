#ifndef _CAL_H_
#define _CAL_H_

enum Gender{male,female};

typedef struct 
{
	enum Gender gender;
	float age;
	float weight;
	float height;
	float resistance;

	float BFM;
	float FFM;
	float TBW;
}Infor;

void BCM_Cal(Infor* person);

#endif